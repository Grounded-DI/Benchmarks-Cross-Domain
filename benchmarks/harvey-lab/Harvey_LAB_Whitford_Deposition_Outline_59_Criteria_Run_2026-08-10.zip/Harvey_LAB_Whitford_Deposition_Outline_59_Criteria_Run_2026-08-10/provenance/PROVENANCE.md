# Provenance

- Benchmark: Harvey Legal Agent Benchmark, `draft-deposition-outline`
- Repository: `https://github.com/harveyai/harvey-labs`
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Acquisition date: 2026-08-10
- Deliverable: `whitford-deposition-outline.docx`
- Source universe: the 12 files listed in `input_sha256.txt`; no outside factual record was used.
- Deliverable SHA-256 at build: `5ce806c82da438b63aff3d1386c0a7189bea1a85e4b52b8d708cd997f6adfc6a`
- Evaluation status: criterion-level self-audit only; not an official Harvey score or certification.
