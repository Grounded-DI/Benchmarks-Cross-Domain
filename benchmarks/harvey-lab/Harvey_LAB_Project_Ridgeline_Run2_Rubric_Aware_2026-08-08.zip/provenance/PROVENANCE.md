# Harvey LAB Run 2 - Rubric-Aware Remediation

- Source repository: `https://github.com/harveyai/harvey-labs.git`
- Pinned commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Commit timestamp: `2026-08-07T10:00:15-07:00`
- Task ID: `corporate-ma/review-data-room-red-flag-review`
- Task title: `Review Data Room for Acquisition Red Flags - M&A Due Diligence Memo`
- Run 2 initialized: `2026-08-08T14:53:57-04:00`
- Runtime label supplied by user: `FastPath / SOL MAX`
- Required outputs: `red-flag-memo.docx`; `red-flag-tracker.xlsx`
- Source set: 13 files (11 DOCX, 2 XLSX), identical to Run 1 by retained input hashes
- Rubric status: visible; Run 2 is explicitly rubric-aware

## Immutable Run 1 baseline

- Provisional result: `36/50` criteria (`72%`), Harvey all-pass task result `FAIL`
- `red-flag-memo.docx`: `f99e09ed7cb8fef70d9dbb48a2c332bfba98c64a6700ede8d5b2a51a72aa2ef6`
- `red-flag-tracker.xlsx`: `29e16eb5b25a423b76079baf484c57415a066a0c3699494854b4f11adc0e4d64`
- Workspace and reattached Run 1 copies were reverified before Run 2 initialization.
- Run 1 files will not be modified or replaced.

## Run 2 protocol

1. Reuse the identical pinned task and 13-source package.
2. Remediate the 14 Run 1 misses without regressing the 36 prior passes.
3. Preserve both source-stated and deterministically recomputed values when they conflict.
4. Render and inspect every DOCX page and workbook sheet.
5. SHA-256 seal both Run 2 outputs before scoring.
6. Audit all 50 criteria against only the sealed Run 2 files.
7. Label any non-Harvey judge result provisional.

## Targeted criteria

`C-005`, `C-025`, `C-027`, `C-028`, `C-030`, `C-032`, `C-037`, `C-041`, `C-045`, `C-046`, `C-047`, `C-048`, `C-049`, and `C-050`.
