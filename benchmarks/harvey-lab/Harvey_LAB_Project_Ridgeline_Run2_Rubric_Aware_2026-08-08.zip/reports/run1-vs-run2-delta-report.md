# Project Ridgeline — Run 1 vs Run 2 Delta Report

**Status:** PROVISIONAL SELF-AUDIT ONLY — not Harvey-certified and not an official leaderboard result.

- Pinned Harvey commit: `55510f0e609ffa5cf6f5df17d9a813ce4bb33d0c`
- Task: `corporate-ma/review-data-room-red-flag-review`
- Run 1: blind, sealed before rubric review — **36/50; all-pass FAIL**
- Run 2: rubric-aware remediation, sealed before scoring — **50/50; all-pass PASS (provisional)**
- Official judge: not run; no configured provider API credentials were available.

## Hashes

| Run | File | SHA-256 |
|---|---|---|
| Run 1 | `red-flag-memo.docx` | `f99e09ed7cb8fef70d9dbb48a2c332bfba98c64a6700ede8d5b2a51a72aa2ef6` |
| Run 1 | `red-flag-tracker.xlsx` | `29e16eb5b25a423b76079baf484c57415a066a0c3699494854b4f11adc0e4d64` |
| Run 2 | `red-flag-memo.docx` | `eedcfb0390edbd6d21cd1e88ed45c90a6dcb3742387f7bf33d302e2834b35487` |
| Run 2 | `red-flag-tracker.xlsx` | `ad75cc772ae3919048b7cf87c9f97d23a64a9fb31d11c649df43dcb75d2e0be5` |

## Fourteen targeted remediations

| Criterion | Class | Change |
|---|---|---|
| C-005 | Substantive | Added Utah R315-3 violation analysis and enforcement, fine, suspension, and shutdown consequences. |
| C-025 | Substantive | Added the five-executive severance schedule: $1.3125M + $1.3125M + $0.425M + $0.375M + $0.350M = $3.775M. |
| C-027 | Substantive | Added mandatory payoff within five business days and the $38.7M principal breakdown. |
| C-028 | Substantive | Added January 2023 origination, January 2026 premium cutoff, and $263,000 calculation. |
| C-030 | Substantive | Scrutinized the $1.8M asbestos add-back as the largest adjustment against 11 years of operations and long-tail exposure. |
| C-032 | Substantive calibration | Removed Casper from red flags and treated timely renewal as cleared/routine monitoring only. |
| C-037 | Presentation / structure | Reorganized all 28 findings into the six required substantive risk categories. |
| C-041 | Presentation / structure | Added a dedicated four-item non-issue/cleared-items section with explanations. |
| C-045 | Presentation / context | Added required IC addressee, Thornfield authors, matter, and January 24, 2025 meeting context. |
| C-046 | Substantive / conflict handling | Preserved source-stated $85.3M / 67.0%, DOE $24.4M / 19.2%, CMMC $14.5M / 11.4%, and separately labeled recomputed $89.2M / 70.1%. |
| C-047 | Substantive | Added $38.7M funded debt with $12.4M revolver and $26.3M term-loan components in net-debt/payoff analysis. |
| C-048 | Substantive | Itemized all five EBITDA add-backs and the exact $5.4M total. |
| C-049 | Substantive | Added 10% holdback ($18.2M–$20.5M), 18-month general survival, six-year environmental/tax survival, and matter-specific protections. |
| C-050 | Substantive | Added Ramirez case number, D. Wyo. court, August 12, 2024 filing date, contamination theory, and $4.8M demand. |

## Criterion-by-criterion delta

| Criterion | Run 1 | Run 2 | Delta | Class / evidence |
|---|---:|---:|---|---|
| C-001 | PASS | PASS | PASS→PASS | **Preserved.** States the three competing EBITDA figures and the exact $1.0M unresolved bridge. Evidence: Memo RF-01. |
| C-002 | PASS | PASS | PASS→PASS | **Preserved.** Names both conflicting source files. Evidence: Memo RF-01 — Sources. |
| C-003 | PASS | PASS | PASS→PASS | **Preserved.** Makes reconciliation a gate to valuation reliance. Evidence: Memo RF-01 — Required response. |
| C-004 | PASS | PASS | PASS→PASS | **Preserved.** Identifies the untransferred Salt Lake City permit and operator mismatch. Evidence: Memo RF-07. |
| C-005 | FAIL | PASS | FAIL→PASS | **Substantive.** Added Utah R315-3 violation analysis and enforcement, fine, suspension, and shutdown consequences. Evidence: Memo RF-07. |
| C-006 | PASS | PASS | PASS→PASS | **Preserved.** Links Pinnacle's dormant/undissolved status to the permit-holder problem. Evidence: Memo RF-07. |
| C-007 | PASS | PASS | PASS→PASS | **Preserved.** Flags the June 2019 assessment as stale and not updated. Evidence: Memo RF-08. |
| C-008 | PASS | PASS | PASS→PASS | **Preserved.** Explains why the old estimate and company-wide accrual may understate Grand Junction exposure. Evidence: Memo RF-08. |
| C-009 | PASS | PASS | PASS→PASS | **Preserved.** Requires an updated Phase II before signing as a transaction gate. Evidence: Memo RF-08 — Required response. |
| C-010 | PASS | PASS | PASS→PASS | **Preserved.** Quantifies DOE concentration, remaining ceiling, and the expected cliff. Evidence: Memo RF-05. |
| C-011 | PASS | PASS | PASS→PASS | **Preserved.** Gives the precise Anti-Assignment Act/FAR framework and stock-sale qualification. Evidence: Memo RF-06. |
| C-012 | PASS | PASS | PASS→PASS | **Preserved.** Connects the known gradual release with the owned-site policy exclusion. Evidence: Memo RF-08. |
| C-013 | PASS | PASS | PASS→PASS | **Preserved.** Cross-references the insurance summary and Phase II source. Evidence: Memo RF-08 — Sources. |
| C-014 | PASS | PASS | PASS→PASS | **Preserved.** Translates the uninsured exposure into escrow, indemnity, and coverage controls. Evidence: Memo RF-08/RF-15. |
| C-015 | PASS | PASS | PASS→PASS | **Preserved.** States the docket, both day counts, rate, and competing penalty totals. Evidence: Memo RF-10. |
| C-016 | PASS | PASS | PASS→PASS | **Preserved.** States that CDPHE is unreserved/unadjusted and distinguishes the separate $1.2M matter. Evidence: Memo RF-10. |
| C-017 | PASS | PASS | PASS→PASS | **Preserved.** Identifies the historic assignment gap and fresh change-of-control consent. Evidence: Memo RF-07. |
| C-018 | PASS | PASS | PASS→PASS | **Preserved.** Analyzes lease and permit authority together at the same site. Evidence: Memo RF-07. |
| C-019 | PASS | PASS | PASS→PASS | **Preserved.** States petition date, unit size/locations, and disclosure omission. Evidence: Memo RF-19. |
| C-020 | PASS | PASS | PASS→PASS | **Preserved.** Explains bargaining, cost, operating, representation, and lender effects. Evidence: Memo RF-19. |
| C-021 | PASS | PASS | PASS→PASS | **Preserved.** Quantifies fleet age, useful life, buyer capex case, and free-cash-flow impact. Evidence: Memo RF-14. |
| C-022 | PASS | PASS | PASS→PASS | **Preserved.** Quantifies the catch-up and specifies valuation/holdback treatment. Evidence: Memo RF-14. |
| C-023 | PASS | PASS | PASS→PASS | **Preserved.** Links the six-month match suspension to safe-harbor compliance. Evidence: Memo RF-20. |
| C-024 | PASS | PASS | PASS→PASS | **Preserved.** States the principal plan and transaction consequences. Evidence: Memo RF-20. |
| C-025 | FAIL | PASS | FAIL→PASS | **Substantive.** Added the five-executive severance schedule: $1.3125M + $1.3125M + $0.425M + $0.375M + $0.350M = $3.775M. Evidence: Memo RF-18. |
| C-026 | PASS | PASS | PASS→PASS | **Preserved.** Identifies and closes the LOI allocation gap. Evidence: Memo RF-18. |
| C-027 | FAIL | PASS | FAIL→PASS | **Substantive.** Added mandatory payoff within five business days and the $38.7M principal breakdown. Evidence: Memo RF-11. |
| C-028 | FAIL | PASS | FAIL→PASS | **Substantive.** Added January 2023 origination, January 2026 premium cutoff, and $263,000 calculation. Evidence: Memo RF-11. |
| C-029 | PASS | PASS | PASS→PASS | **Preserved.** Quotes the LOI concept and requires express premium/breakage inclusion. Evidence: Memo RF-11. |
| C-030 | FAIL | PASS | FAIL→PASS | **Substantive.** Scrutinized the $1.8M asbestos add-back as the largest adjustment against 11 years of operations and long-tail exposure. Evidence: Memo RF-17. |
| C-031 | PASS | PASS | PASS→PASS | **Preserved.** Identifies long-tail exposure and requires specialized indemnity/survival. Evidence: Memo RF-17. |
| C-032 | FAIL | PASS | FAIL→PASS | **Substantive calibration.** Removed Casper from red flags and treated timely renewal as cleared/routine monitoring only. Evidence: Memo CL-01. |
| C-033 | PASS | PASS | PASS→PASS | **Preserved.** Treats the clause as standard and only relevant to aggregate concentration. Evidence: Memo CL-02. |
| C-034 | PASS | PASS | PASS→PASS | **Preserved.** Clears registration itself while preserving separate medium diligence. Evidence: Memo CL-03. |
| C-035 | PASS | PASS | PASS→PASS | **Preserved.** Clears appraisal age without clearing distinct contamination issues. Evidence: Memo CL-04. |
| C-036 | PASS | PASS | PASS→PASS | **Preserved.** Executive section highlights six critical priorities. Evidence: Memo — Priority findings. |
| C-037 | FAIL | PASS | FAIL→PASS | **Presentation / structure.** Reorganized all 28 findings into the six required substantive risk categories. Evidence: Memo — risk-category headings. |
| C-038 | PASS | PASS | PASS→PASS | **Preserved.** Every one of the 28 finding blocks carries Critical, High, or Medium severity. Evidence: Memo RF-01–RF-28. |
| C-039 | PASS | PASS | PASS→PASS | **Preserved.** Every one of the 28 finding blocks names one or more source documents. Evidence: Memo RF-01–RF-28. |
| C-040 | PASS | PASS | PASS→PASS | **Preserved.** Every one of the 28 finding blocks includes a specific required response. Evidence: Memo RF-01–RF-28. |
| C-041 | FAIL | PASS | FAIL→PASS | **Presentation / structure.** Added a dedicated four-item non-issue/cleared-items section with explanations. Evidence: Memo — Non-issues and cleared items. |
| C-042 | PASS | PASS | PASS→PASS | **Preserved.** The required spreadsheet exists and opens. Evidence: Sealed red-flag-tracker.xlsx. |
| C-043 | PASS | PASS | PASS→PASS | **Preserved.** Includes all required fields and substantially equivalent labels. Evidence: Tracker — Red Flag Tracker!A4:M32. |
| C-044 | PASS | PASS | PASS→PASS | **Preserved.** Contains a row for every memo finding RF-01 through RF-28. Evidence: Tracker — Red Flag Tracker!A5:M32. |
| C-045 | FAIL | PASS | FAIL→PASS | **Presentation / context.** Added required IC addressee, Thornfield authors, matter, and January 24, 2025 meeting context. Evidence: Memo cover. |
| C-046 | FAIL | PASS | FAIL→PASS | **Substantive / conflict handling.** Preserved source-stated $85.3M / 67.0%, DOE $24.4M / 19.2%, CMMC $14.5M / 11.4%, and separately labeled recomputed $89.2M / 70.1%. Evidence: Memo RF-04/RF-06. |
| C-047 | FAIL | PASS | FAIL→PASS | **Substantive.** Added $38.7M funded debt with $12.4M revolver and $26.3M term-loan components in net-debt/payoff analysis. Evidence: Memo RF-11. |
| C-048 | FAIL | PASS | FAIL→PASS | **Substantive.** Itemized all five EBITDA add-backs and the exact $5.4M total. Evidence: Memo RF-01. |
| C-049 | FAIL | PASS | FAIL→PASS | **Substantive.** Added 10% holdback ($18.2M–$20.5M), 18-month general survival, six-year environmental/tax survival, and matter-specific protections. Evidence: Memo — Required deal posture. |
| C-050 | FAIL | PASS | FAIL→PASS | **Substantive.** Added Ramirez case number, D. Wyo. court, August 12, 2024 filing date, contamination theory, and $4.8M demand. Evidence: Memo RF-16. |

## Benchmark/source conflict retained

C-046 requires the workbook's source-stated top-ten figure: **$85.3M / 67.0%**, including DOE at **$24.4M / 19.2%** and Consolidated Mining at **$14.5M / 11.4%**. Deterministic re-ranking produces **$89.2M / 70.1%**. Run 2 labels the former **source-stated** and the latter **recomputed**; neither is silently substituted for the other.

## QA and limits

- Visual QA: 15 DOCX pages and 7 workbook sheets rendered and inspected.
- Workbook QA: 57 formulas; 0 recalculation errors after a QA-only LibreOffice recalculation.
- File integrity: both deliverables passed ZIP/package checks and were rehashed after audit.
- The 50/50 result is a same-runtime provisional self-audit against the public rubric. It is not an official Harvey score, certification, or leaderboard placement.
